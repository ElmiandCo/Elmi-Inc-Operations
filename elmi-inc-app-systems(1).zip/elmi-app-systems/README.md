# Elmi Inc. App Systems

Frontend demo for Elmi Inc. Consulting's internal contracting/procurement operating system.

## Included
- Front-end demo login
- Dashboard
- 7-step Company Profile / vendor-registration workspace
- Opportunities
- Bids & Proposals
- Contracts and work orders
- Clients / Agencies
- Consultants / staffing bench
- Documents with multi-file browser upload demo
- Compliance
- Finance

## Important
This build is intentionally frontend-only. Authentication, database persistence, secure document storage, and production handling of sensitive tax/payment information should be connected before using real confidential data.
